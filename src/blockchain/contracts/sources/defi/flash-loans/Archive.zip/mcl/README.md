# MCL-FlashloanDemo

Make sure there's some BNB token deposited into Demo smart contract to be paid as flashloan fee.